import { Text, TouchableOpacity, StyleSheet } from 'react-native';

interface CategoryButtonProps {
  id: string | null;
  name: string;
  icon: string;
  isSelected: boolean;
  onSelect: () => void;
}

export default function CategoryButton({ id, name, icon, isSelected, onSelect }: CategoryButtonProps) {
  return (
    <TouchableOpacity
      style={[
        styles.container,
        isSelected && styles.selectedContainer
      ]}
      onPress={onSelect}
    >
      <Text style={styles.icon}>{icon}</Text>
      <Text style={[
        styles.name,
        isSelected && styles.selectedName
      ]}>
        {name}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
    backgroundColor: '#F5F5F5',
  },
  selectedContainer: {
    backgroundColor: '#E8F5E9',
  },
  icon: {
    fontSize: 16,
    marginRight: 4,
  },
  name: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#757575',
  },
  selectedName: {
    color: '#2E7D32',
  },
});