import { useState, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Image, Platform } from 'react-native';
import { Send } from 'lucide-react-native';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

const INITIAL_MESSAGES: Message[] = [
  {
    id: '1',
    text: "Hello! I'm your FarmConnect assistant. How can I help you today?",
    sender: 'bot',
    timestamp: new Date(),
  },
];

const QUICK_RESPONSES = [
  "How do I list my products?",
  "Where can I find local farmers?",
  "How do payments work?",
  "What are the delivery options?",
];

export default function ChatBot() {
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [inputText, setInputText] = useState('');
  const scrollViewRef = useRef<ScrollView>(null);

  const handleSend = () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText.trim(),
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');

    // Simulate bot response
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: generateBotResponse(inputText.trim()),
        sender: 'bot',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, botResponse]);
    }, 1000);
  };

  const generateBotResponse = (userInput: string): string => {
    const input = userInput.toLowerCase();
    
    if (input.includes('list') && input.includes('product')) {
      return "To list your products, go to your Profile tab, select 'My Products', and click the '+' button. You can add product details, photos, and set prices there.";
    }
    
    if (input.includes('payment') || input.includes('pay')) {
      return "We support various payment methods including credit cards, bank transfers, and mobile payments. All transactions are secure and protected. Would you like to know more about our payment process?";
    }
    
    if (input.includes('delivery') || input.includes('shipping')) {
      return "Delivery options vary by location and seller. Most farmers offer local pickup, and some provide delivery within a certain radius. You can check delivery options on each product listing.";
    }
    
    if (input.includes('find') && (input.includes('farmer') || input.includes('farms'))) {
      return "You can find local farmers in the Home tab. Use the search feature or browse by category. You can also filter by location to find farmers nearest to you.";
    }
    
    return "I'm here to help! You can ask me about listing products, finding local farmers, payments, or delivery options. What would you like to know?";
  };

  const handleQuickResponse = (response: string) => {
    setInputText(response);
  };

  useEffect(() => {
    // Scroll to bottom when messages change
    scrollViewRef.current?.scrollToEnd({ animated: true });
  }, [messages]);

  return (
    <View style={styles.container}>
      <ScrollView
        ref={scrollViewRef}
        style={styles.messagesContainer}
        contentContainerStyle={styles.messagesContent}
      >
        {messages.map((message) => (
          <View
            key={message.id}
            style={[
              styles.messageWrapper,
              message.sender === 'user' ? styles.userMessageWrapper : styles.botMessageWrapper,
            ]}
          >
            {message.sender === 'bot' && (
              <Image
                source={{ uri: 'https://images.pexels.com/photos/7267852/pexels-photo-7267852.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' }}
                style={styles.botAvatar}
              />
            )}
            <View
              style={[
                styles.message,
                message.sender === 'user' ? styles.userMessage : styles.botMessage,
              ]}
            >
              <Text style={styles.messageText}>{message.text}</Text>
              <Text style={styles.timestamp}>
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </Text>
            </View>
          </View>
        ))}
      </ScrollView>

      <View style={styles.quickResponsesContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {QUICK_RESPONSES.map((response, index) => (
            <TouchableOpacity
              key={index}
              style={styles.quickResponse}
              onPress={() => handleQuickResponse(response)}
            >
              <Text style={styles.quickResponseText}>{response}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          value={inputText}
          onChangeText={setInputText}
          placeholder="Type your message..."
          multiline
          maxLength={500}
          onSubmitEditing={handleSend}
        />
        <TouchableOpacity
          style={[styles.sendButton, !inputText.trim() && styles.sendButtonDisabled]}
          onPress={handleSend}
          disabled={!inputText.trim()}
        >
          <Send size={20} color={inputText.trim() ? '#FFFFFF' : '#A5D6A7'} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  messagesContainer: {
    flex: 1,
    padding: 16,
  },
  messagesContent: {
    paddingBottom: 16,
  },
  messageWrapper: {
    flexDirection: 'row',
    marginBottom: 16,
    maxWidth: '80%',
  },
  userMessageWrapper: {
    alignSelf: 'flex-end',
  },
  botMessageWrapper: {
    alignSelf: 'flex-start',
  },
  botAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    marginRight: 8,
  },
  message: {
    padding: 12,
    borderRadius: 16,
  },
  userMessage: {
    backgroundColor: '#2E7D32',
    borderBottomRightRadius: 4,
  },
  botMessage: {
    backgroundColor: '#F5F5F5',
    borderBottomLeftRadius: 4,
  },
  messageText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#333333',
    marginBottom: 4,
  },
  timestamp: {
    fontFamily: 'Poppins-Regular',
    fontSize: 10,
    color: '#999999',
    alignSelf: 'flex-end',
  },
  quickResponsesContainer: {
    padding: 8,
    borderTopWidth: 1,
    borderTopColor: '#EEEEEE',
  },
  quickResponse: {
    backgroundColor: '#E8F5E9',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
  },
  quickResponseText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    color: '#2E7D32',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#EEEEEE',
  },
  input: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    borderRadius: 24,
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 8,
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    maxHeight: 100,
  },
  sendButton: {
    backgroundColor: '#2E7D32',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonDisabled: {
    backgroundColor: '#E8F5E9',
  },
});