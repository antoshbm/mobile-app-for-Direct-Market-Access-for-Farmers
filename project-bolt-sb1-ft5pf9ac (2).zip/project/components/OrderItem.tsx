import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { ChevronRight } from 'lucide-react-native';

interface OrderProduct {
  id: string;
  name: string;
  quantity: number;
  price: number;
  image: string;
}

interface Order {
  id: string;
  date: string;
  status: string;
  totalAmount: number;
  products: OrderProduct[];
  farmerName: string;
  farmerImage: string;
}

interface OrderItemProps {
  order: Order;
  onPress: () => void;
  onTrack: () => void;
  onReview: () => void;
  onReorder: () => void;
}

export default function OrderItem({ order, onPress, onTrack, onReview, onReorder }: OrderItemProps) {
  const getStatusColor = (status: string) => {
    switch(status) {
      case 'pending': return '#FFC107';
      case 'processing': return '#2196F3';
      case 'shipped': return '#9C27B0';
      case 'delivered': return '#4CAF50';
      case 'cancelled': return '#F44336';
      default: return '#757575';
    }
  };

  const getStatusText = (status: string) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  const productCount = order.products.length;
  const mainProduct = order.products[0];

  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={styles.header}>
        <View style={styles.farmerInfo}>
          <Image source={{ uri: order.farmerImage }} style={styles.farmerImage} />
          <Text style={styles.farmerName}>{order.farmerName}</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: `${getStatusColor(order.status)}20` }]}>
          <Text style={[styles.statusText, { color: getStatusColor(order.status) }]}>
            {getStatusText(order.status)}
          </Text>
        </View>
      </View>
      
      <View style={styles.orderContent}>
        <Image source={{ uri: mainProduct.image }} style={styles.productImage} />
        <View style={styles.orderInfo}>
          <Text style={styles.orderTitle}>
            {mainProduct.name} {productCount > 1 && `+ ${productCount - 1} more`}
          </Text>
          <Text style={styles.orderDate}>{order.date}</Text>
          <View style={styles.orderBottom}>
            <Text style={styles.orderTotal}>${order.totalAmount.toFixed(2)}</Text>
            <ChevronRight size={16} color="#CCCCCC" />
          </View>
        </View>
      </View>
      
      {order.status === 'delivered' && (
        <TouchableOpacity style={styles.reviewButton} onPress={onReview}>
          <Text style={styles.reviewButtonText}>Leave a Review</Text>
        </TouchableOpacity>
      )}
      
      {(order.status === 'pending' || order.status === 'processing') && (
        <TouchableOpacity style={styles.trackButton} onPress={onTrack}>
          <Text style={styles.trackButtonText}>Track Order</Text>
        </TouchableOpacity>
      )}
      
      {order.status === 'cancelled' && (
        <TouchableOpacity style={styles.reorderButton} onPress={onReorder}>
          <Text style={styles.reorderButtonText}>Order Again</Text>
        </TouchableOpacity>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    marginBottom: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  farmerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  farmerImage: {
    width: 24,
    height: 24,
    borderRadius: 12,
    marginRight: 8,
  },
  farmerName: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#333333',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  statusText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
  },
  orderContent: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
    paddingBottom: 12,
    marginBottom: 12,
  },
  productImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 12,
  },
  orderInfo: {
    flex: 1,
  },
  orderTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 14,
    color: '#333333',
    marginBottom: 4,
  },
  orderDate: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: '#757575',
    marginBottom: 8,
  },
  orderBottom: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  orderTotal: {
    fontFamily: 'Poppins-Bold',
    fontSize: 14,
    color: '#2E7D32',
  },
  reviewButton: {
    backgroundColor: '#E8F5E9',
    paddingVertical: 8,
    borderRadius: 4,
    alignItems: 'center',
  },
  reviewButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    color: '#2E7D32',
  },
  trackButton: {
    backgroundColor: '#2E7D32',
    paddingVertical: 8,
    borderRadius: 4,
    alignItems: 'center',
  },
  trackButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    color: '#FFFFFF',
  },
  reorderButton: {
    backgroundColor: '#E8F5E9',
    paddingVertical: 8,
    borderRadius: 4,
    alignItems: 'center',
  },
  reorderButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    color: '#2E7D32',
  },
});