import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';

interface Conversation {
  id: string;
  name: string;
  lastMessage: string;
  time: string;
  image: string;
  unreadCount: number;
  userType: 'farmer' | 'consumer' | 'retailer';
}

interface ChatItemProps {
  conversation: Conversation;
}

export default function ChatItem({ conversation }: ChatItemProps) {
  return (
    <TouchableOpacity style={styles.container}>
      <View style={styles.avatarContainer}>
        <Image source={{ uri: conversation.image }} style={styles.avatar} />
        <View style={[
          styles.userTypeBadge,
          conversation.userType === 'farmer' ? styles.farmerBadge : 
          conversation.userType === 'retailer' ? styles.retailerBadge : styles.consumerBadge
        ]}>
          <Text style={styles.userTypeText}>
            {conversation.userType === 'farmer' ? '🚜' : 
             conversation.userType === 'retailer' ? '🏪' : '🛒'}
          </Text>
        </View>
      </View>
      
      <View style={styles.contentContainer}>
        <View style={styles.topRow}>
          <Text style={styles.name} numberOfLines={1}>{conversation.name}</Text>
          <Text style={styles.time}>{conversation.time}</Text>
        </View>
        <View style={styles.bottomRow}>
          <Text style={styles.message} numberOfLines={1}>{conversation.lastMessage}</Text>
          {conversation.unreadCount > 0 && (
            <View style={styles.unreadBadge}>
              <Text style={styles.unreadCount}>{conversation.unreadCount}</Text>
            </View>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    padding: 12,
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  avatarContainer: {
    position: 'relative',
    marginRight: 12,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  userTypeBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 20,
    height: 20,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  farmerBadge: {
    backgroundColor: '#2E7D32',
  },
  retailerBadge: {
    backgroundColor: '#0288D1',
  },
  consumerBadge: {
    backgroundColor: '#FFA000',
  },
  userTypeText: {
    fontSize: 10,
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  name: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 14,
    color: '#333333',
    flex: 1,
    marginRight: 8,
  },
  time: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: '#999999',
  },
  bottomRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  message: {
    fontFamily: 'Poppins-Regular',
    fontSize: 13,
    color: '#666666',
    flex: 1,
    marginRight: 8,
  },
  unreadBadge: {
    backgroundColor: '#2E7D32',
    borderRadius: 10,
    width: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  unreadCount: {
    fontFamily: 'Poppins-Medium',
    fontSize: 10,
    color: '#FFFFFF',
  },
});