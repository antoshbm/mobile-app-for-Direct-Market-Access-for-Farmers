import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { Heart } from 'lucide-react-native';
import { useState } from 'react';

interface Product {
  id: string;
  name: string;
  price: number;
  unit: string;
  image: string;
  farmerName: string;
  farmerLocation: string;
  category: string;
  description: string;
  stock: number;
  rating: number;
  organic: boolean;
}

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);

  return (
    <TouchableOpacity style={styles.container}>
      <View style={styles.imageContainer}>
        <Image source={{ uri: product.image }} style={styles.image} />
        <TouchableOpacity 
          style={styles.favoriteButton} 
          onPress={() => setIsFavorite(!isFavorite)}
        >
          <Heart 
            size={18} 
            color={isFavorite ? '#E53935' : '#FFFFFF'} 
            fill={isFavorite ? '#E53935' : 'none'} 
          />
        </TouchableOpacity>
        {product.organic && (
          <View style={styles.organicBadge}>
            <Text style={styles.organicText}>Organic</Text>
          </View>
        )}
      </View>
      <View style={styles.infoContainer}>
        <Text style={styles.name} numberOfLines={1}>{product.name}</Text>
        <View style={styles.farmerInfo}>
          <Text style={styles.farmerName} numberOfLines={1}>{product.farmerName}</Text>
          <Text style={styles.farmerLocation} numberOfLines={1}>{product.farmerLocation}</Text>
        </View>
        <View style={styles.bottomRow}>
          <Text style={styles.price}>${product.price.toFixed(2)}<Text style={styles.unit}>/{product.unit}</Text></Text>
          <TouchableOpacity style={styles.addButton}>
            <Text style={styles.addButtonText}>Add</Text>
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '48%',
    marginBottom: 16,
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    overflow: 'hidden',
  },
  imageContainer: {
    position: 'relative',
  },
  image: {
    width: '100%',
    height: 120,
    resizeMode: 'cover',
  },
  favoriteButton: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  organicBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    backgroundColor: '#2E7D32',
  },
  organicText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 10,
    color: '#FFFFFF',
  },
  infoContainer: {
    padding: 12,
  },
  name: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 14,
    color: '#333333',
    marginBottom: 4,
  },
  farmerInfo: {
    marginBottom: 8,
  },
  farmerName: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    color: '#666666',
  },
  farmerLocation: {
    fontFamily: 'Poppins-Regular',
    fontSize: 10,
    color: '#999999',
  },
  bottomRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  price: {
    fontFamily: 'Poppins-Bold',
    fontSize: 14,
    color: '#2E7D32',
  },
  unit: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: '#757575',
  },
  addButton: {
    backgroundColor: '#E8F5E9',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 4,
  },
  addButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    color: '#2E7D32',
  },
});