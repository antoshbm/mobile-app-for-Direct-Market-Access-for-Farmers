import { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Switch, Alert, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '@/context/AuthContext';
import { CreditCard, Settings, Bell, ShieldCheck, CircleHelp as HelpCircle, LogOut, ChevronRight } from 'lucide-react-native';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '@/lib/supabase';

export default function ProfileScreen() {
  const { user, signOut } = useAuth();
  const router = useRouter();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  
  const handleSignOut = () => {
    Alert.alert(
      "Sign Out",
      "Are you sure you want to sign out?",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        { 
          text: "Sign Out", 
          onPress: async () => {
            try {
              await signOut();
              router.replace('/login');
            } catch (error) {
              Alert.alert('Error', 'Failed to sign out. Please try again.');
            }
          },
          style: "destructive"
        }
      ]
    );
  };

  const handleImagePick = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 1,
      });

      if (!result.canceled && result.assets[0].uri) {
        // Upload image to Supabase Storage
        const uri = result.assets[0].uri;
        const fileName = `profile-${user?.id}-${Date.now()}.jpg`;
        
        // Convert URI to Blob
        const response = await fetch(uri);
        const blob = await response.blob();
        
        const { data, error } = await supabase.storage
          .from('profiles')
          .upload(fileName, blob);

        if (error) throw error;

        // Update user profile with new image URL
        const imageUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/storage/v1/object/public/profiles/${fileName}`;
        
        const { error: updateError } = await supabase
          .from('users')
          .update({ profile_image: imageUrl })
          .eq('id', user?.id);

        if (updateError) throw updateError;

        Alert.alert('Success', 'Profile image updated successfully!');
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to update profile image. Please try again.');
    }
  };

  const navigateToProducts = () => {
    router.push('/(tabs)/profile/products');
  };

  const navigateToAnalytics = () => {
    router.push('/(tabs)/profile/analytics');
  };

  const navigateToFarmProfile = () => {
    router.push('/(tabs)/profile/farm');
  };

  const navigateToPayments = () => {
    router.push('/(tabs)/profile/payments');
  };

  const navigateToAddresses = () => {
    router.push('/(tabs)/profile/addresses');
  };

  const navigateToPrivacy = () => {
    router.push('/(tabs)/profile/privacy');
  };

  const navigateToHelp = () => {
    router.push('/(tabs)/profile/help');
  };

  const navigateToAbout = () => {
    router.push('/(tabs)/profile/about');
  };

  const renderFarmerStats = () => {
    if (user?.type !== 'farmer') return null;
    
    return (
      <View style={styles.statsContainer}>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>32</Text>
          <Text style={styles.statLabel}>Products</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statValue}>128</Text>
          <Text style={styles.statLabel}>Orders</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statValue}>4.9</Text>
          <Text style={styles.statLabel}>Rating</Text>
        </View>
      </View>
    );
  };

  const renderFarmerActions = () => {
    if (user?.type !== 'farmer') return null;
    
    return (
      <View style={styles.sectionContainer}>
        <Text style={styles.sectionTitle}>Farmer Tools</Text>
        <TouchableOpacity style={styles.menuItem} onPress={navigateToProducts}>
          <View style={styles.menuIconContainer}>
            <CreditCard size={20} color="#2E7D32" />
          </View>
          <Text style={styles.menuItemText}>My Products</Text>
          <ChevronRight size={16} color="#CCCCCC" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.menuItem} onPress={navigateToAnalytics}>
          <View style={styles.menuIconContainer}>
            <Image 
              source={{ uri: 'https://images.pexels.com/photos/3652131/pexels-photo-3652131.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' }} 
              style={styles.menuIcon} 
            />
          </View>
          <Text style={styles.menuItemText}>Sales Analytics</Text>
          <ChevronRight size={16} color="#CCCCCC" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.menuItem} onPress={navigateToFarmProfile}>
          <View style={styles.menuIconContainer}>
            <Image 
              source={{ uri: 'https://images.pexels.com/photos/6169659/pexels-photo-6169659.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' }} 
              style={styles.menuIcon} 
            />
          </View>
          <Text style={styles.menuItemText}>Farm Profile</Text>
          <ChevronRight size={16} color="#CCCCCC" />
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={styles.screenTitle}>My Profile</Text>
          <TouchableOpacity>
            <Settings size={24} color="#333333" />
          </TouchableOpacity>
        </View>

        <View style={styles.profileContainer}>
          <TouchableOpacity onPress={handleImagePick}>
            <Image 
              source={{ uri: user?.profileImage || 'https://images.pexels.com/photos/1542252/pexels-photo-1542252.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' }} 
              style={styles.profileImage}
            />
          </TouchableOpacity>
          <View style={styles.profileInfo}>
            <Text style={styles.userName}>{user?.name || 'Guest User'}</Text>
            <Text style={styles.userType}>
              {user?.type === 'farmer' ? '🚜 Farmer' : 
               user?.type === 'retailer' ? '🏪 Retailer' : '🛒 Consumer'}
            </Text>
            <TouchableOpacity style={styles.editProfileButton}>
              <Text style={styles.editProfileButtonText}>Edit Profile</Text>
            </TouchableOpacity>
          </View>
        </View>

        {renderFarmerStats()}
        {renderFarmerActions()}

        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>Account Settings</Text>
          <TouchableOpacity style={styles.menuItem} onPress={navigateToPayments}>
            <View style={styles.menuIconContainer}>
              <CreditCard size={20} color="#2E7D32" />
            </View>
            <Text style={styles.menuItemText}>Payment Methods</Text>
            <ChevronRight size={16} color="#CCCCCC" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.menuItem} onPress={navigateToAddresses}>
            <View style={styles.menuIconContainer}>
              <Image 
                source={{ uri: 'https://images.pexels.com/photos/2263436/pexels-photo-2263436.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' }} 
                style={styles.menuIcon} 
              />
            </View>
            <Text style={styles.menuItemText}>Addresses</Text>
            <ChevronRight size={16} color="#CCCCCC" />
          </TouchableOpacity>
          <View style={styles.menuItem}>
            <View style={styles.menuIconContainer}>
              <Bell size={20} color="#2E7D32" />
            </View>
            <Text style={styles.menuItemText}>Notifications</Text>
            <Switch
              value={notificationsEnabled}
              onValueChange={setNotificationsEnabled}
              trackColor={{ false: '#CCCCCC', true: '#A5D6A7' }}
              thumbColor={notificationsEnabled ? '#2E7D32' : '#F5F5F5'}
            />
          </View>
          <TouchableOpacity style={styles.menuItem} onPress={navigateToPrivacy}>
            <View style={styles.menuIconContainer}>
              <ShieldCheck size={20} color="#2E7D32" />
            </View>
            <Text style={styles.menuItemText}>Privacy & Security</Text>
            <ChevronRight size={16} color="#CCCCCC" />
          </TouchableOpacity>
        </View>

        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>Support</Text>
          <TouchableOpacity style={styles.menuItem} onPress={navigateToHelp}>
            <View style={styles.menuIconContainer}>
              <HelpCircle size={20} color="#2E7D32" />
            </View>
            <Text style={styles.menuItemText}>Help Center</Text>
            <ChevronRight size={16} color="#CCCCCC" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.menuItem} onPress={navigateToAbout}>
            <View style={styles.menuIconContainer}>
              <Image 
                source={{ uri: 'https://images.pexels.com/photos/327533/pexels-photo-327533.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' }} 
                style={styles.menuIcon} 
              />
            </View>
            <Text style={styles.menuItemText}>About FarmConnect</Text>
            <ChevronRight size={16} color="#CCCCCC" />
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.logoutButton} onPress={handleSignOut}>
          <LogOut size={20} color="#E53935" />
          <Text style={styles.logoutButtonText}>Sign Out</Text>
        </TouchableOpacity>

        <Text style={styles.versionText}>Version 1.0.0</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  scrollContent: {
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: 16,
  },
  screenTitle: {
    fontFamily: 'Poppins-Bold',
    fontSize: 20,
    color: '#333333',
  },
  profileContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#F9F9F9',
    marginHorizontal: 16,
    borderRadius: 12,
    marginBottom: 24,
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  userName: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: '#333333',
    marginBottom: 4,
  },
  userType: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#666666',
    marginBottom: 12,
  },
  editProfileButton: {
    backgroundColor: '#2E7D32',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 4,
    alignSelf: 'flex-start',
  },
  editProfileButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    color: '#FFFFFF',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 16,
    backgroundColor: '#F9F9F9',
    marginHorizontal: 16,
    borderRadius: 12,
    marginBottom: 24,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontFamily: 'Poppins-Bold',
    fontSize: 22,
    color: '#2E7D32',
    marginBottom: 4,
  },
  statLabel: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: '#666666',
  },
  statDivider: {
    width: 1,
    height: '80%',
    backgroundColor: '#DDDDDD',
  },
  sectionContainer: {
    paddingHorizontal: 16,
    marginBottom: 24,
  },
  sectionTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: '#333333',
    marginBottom: 16,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  menuIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  menuIcon: {
    width: 20,
    height: 20,
    borderRadius: 10,
  },
  menuItemText: {
    flex: 1,
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#333333',
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    marginHorizontal: 16,
    borderWidth: 1,
    borderColor: '#FFCDD2',
    borderRadius: 8,
    backgroundColor: '#FFEBEE',
    marginBottom: 24,
  },
  logoutButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#E53935',
    marginLeft: 8,
  },
  versionText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: '#999999',
    textAlign: 'center',
  },
});