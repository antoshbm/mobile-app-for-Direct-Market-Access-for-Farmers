import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { MessageSquare, Notebook as Robot } from 'lucide-react-native';
import ChatBot from '@/components/ChatBot';

export default function MessagesScreen() {
  const [showChatBot, setShowChatBot] = useState(false);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Messages</Text>
        <TouchableOpacity 
          style={styles.chatBotButton}
          onPress={() => setShowChatBot(!showChatBot)}
        >
          {showChatBot ? (
            <MessageSquare size={24} color="#2E7D32" />
          ) : (
            <Robot size={24} color="#2E7D32" />
          )}
        </TouchableOpacity>
      </View>

      {showChatBot ? (
        <ChatBot />
      ) : (
        <View style={styles.emptyContainer}>
          <Robot size={64} color="#CCCCCC" />
          <Text style={styles.emptyTitle}>No messages yet</Text>
          <Text style={styles.emptySubtitle}>
            Start a conversation with farmers or use our AI assistant for help
          </Text>
          <TouchableOpacity 
            style={styles.chatBotPromptButton}
            onPress={() => setShowChatBot(true)}
          >
            <Text style={styles.chatBotPromptText}>Ask AI Assistant</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 60,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  headerTitle: {
    fontFamily: 'Poppins-Bold',
    fontSize: 20,
    color: '#333333',
  },
  chatBotButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  emptyTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: '#333333',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#757575',
    textAlign: 'center',
    marginBottom: 24,
  },
  chatBotPromptButton: {
    backgroundColor: '#2E7D32',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  chatBotPromptText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#FFFFFF',
  },
});