import { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { MapPin, Plus, Trash2 } from 'lucide-react-native';

interface Address {
  id: string;
  type: 'home' | 'work' | 'other';
  street: string;
  city: string;
  state: string;
  zipCode: string;
  isDefault: boolean;
}

export default function AddressesScreen() {
  const [showAddAddress, setShowAddAddress] = useState(false);
  const [addressType, setAddressType] = useState<'home' | 'work' | 'other'>('home');
  const [street, setStreet] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [addresses, setAddresses] = useState<Address[]>([
    {
      id: '1',
      type: 'home',
      street: '123 Main Street',
      city: 'New York',
      state: 'NY',
      zipCode: '10001',
      isDefault: true,
    },
    {
      id: '2',
      type: 'work',
      street: '456 Business Ave',
      city: 'New York',
      state: 'NY',
      zipCode: '10002',
      isDefault: false,
    },
  ]);

  const handleAddAddress = () => {
    if (!street || !city || !state || !zipCode) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    const newAddress: Address = {
      id: Date.now().toString(),
      type: addressType,
      street,
      city,
      state,
      zipCode,
      isDefault: addresses.length === 0,
    };

    setAddresses([...addresses, newAddress]);
    setShowAddAddress(false);
    resetForm();
  };

  const handleDeleteAddress = (id: string) => {
    Alert.alert(
      'Delete Address',
      'Are you sure you want to delete this address?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Delete',
          onPress: () => {
            setAddresses(addresses.filter(address => address.id !== id));
          },
          style: 'destructive',
        },
      ],
    );
  };

  const handleSetDefault = (id: string) => {
    setAddresses(addresses.map(address => ({
      ...address,
      isDefault: address.id === id,
    })));
  };

  const resetForm = () => {
    setAddressType('home');
    setStreet('');
    setCity('');
    setState('');
    setZipCode('');
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>My Addresses</Text>
      </View>

      {addresses.map(address => (
        <View key={address.id} style={styles.addressContainer}>
          <View style={styles.addressHeader}>
            <View style={styles.addressTypeContainer}>
              <MapPin size={20} color="#2E7D32" />
              <Text style={styles.addressType}>
                {address.type.charAt(0).toUpperCase() + address.type.slice(1)}
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => handleDeleteAddress(address.id)}
              style={styles.deleteButton}
            >
              <Trash2 size={20} color="#E53935" />
            </TouchableOpacity>
          </View>
          
          <Text style={styles.addressText}>{address.street}</Text>
          <Text style={styles.addressText}>
            {address.city}, {address.state} {address.zipCode}
          </Text>
          
          {address.isDefault ? (
            <View style={styles.defaultBadge}>
              <Text style={styles.defaultText}>Default Address</Text>
            </View>
          ) : (
            <TouchableOpacity
              style={styles.setDefaultButton}
              onPress={() => handleSetDefault(address.id)}
            >
              <Text style={styles.setDefaultText}>Set as Default</Text>
            </TouchableOpacity>
          )}
        </View>
      ))}

      {!showAddAddress ? (
        <TouchableOpacity
          style={styles.addButton}
          onPress={() => setShowAddAddress(true)}
        >
          <Plus size={20} color="#2E7D32" />
          <Text style={styles.addButtonText}>Add New Address</Text>
        </TouchableOpacity>
      ) : (
        <View style={styles.addAddressForm}>
          <Text style={styles.formTitle}>Add New Address</Text>

          <View style={styles.addressTypeSelector}>
            {(['home', 'work', 'other'] as const).map(type => (
              <TouchableOpacity
                key={type}
                style={[
                  styles.typeButton,
                  addressType === type && styles.selectedTypeButton,
                ]}
                onPress={() => setAddressType(type)}
              >
                <Text
                  style={[
                    styles.typeButtonText,
                    addressType === type && styles.selectedTypeButtonText,
                  ]}
                >
                  {type.charAt(0).toUpperCase() + type.slice(1)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>Street Address</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter street address"
              value={street}
              onChangeText={setStreet}
            />
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>City</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter city"
              value={city}
              onChangeText={setCity}
            />
          </View>

          <View style={styles.row}>
            <View style={[styles.inputContainer, { flex: 1, marginRight: 8 }]}>
              <Text style={styles.label}>State</Text>
              <TextInput
                style={styles.input}
                placeholder="State"
                value={state}
                onChangeText={setState}
                maxLength={2}
                autoCapitalize="characters"
              />
            </View>
            <View style={[styles.inputContainer, { flex: 1, marginLeft: 8 }]}>
              <Text style={styles.label}>ZIP Code</Text>
              <TextInput
                style={styles.input}
                placeholder="ZIP Code"
                value={zipCode}
                onChangeText={setZipCode}
                keyboardType="numeric"
                maxLength={5}
              />
            </View>
          </View>

          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={[styles.button, styles.cancelButton]}
              onPress={() => {
                setShowAddAddress(false);
                resetForm();
              }}
            >
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.button, styles.saveButton]}
              onPress={handleAddAddress}
            >
              <Text style={styles.saveButtonText}>Save Address</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    padding: 16,
    paddingTop: 60,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  title: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: '#333333',
  },
  addressContainer: {
    margin: 16,
    padding: 16,
    backgroundColor: '#F5F5F5',
    borderRadius: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  addressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  addressTypeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  addressType: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: '#333333',
    marginLeft: 8,
  },
  deleteButton: {
    padding: 4,
  },
  addressText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#666666',
    marginBottom: 4,
  },
  defaultBadge: {
    backgroundColor: '#E8F5E9',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    alignSelf: 'flex-start',
    marginTop: 12,
  },
  defaultText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    color: '#2E7D32',
  },
  setDefaultButton: {
    marginTop: 12,
  },
  setDefaultText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#2E7D32',
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    margin: 16,
    backgroundColor: '#E8F5E9',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#2E7D32',
    borderStyle: 'dashed',
  },
  addButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: '#2E7D32',
    marginLeft: 8,
  },
  addAddressForm: {
    margin: 16,
    padding: 16,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#EEEEEE',
  },
  formTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: '#333333',
    marginBottom: 16,
  },
  addressTypeSelector: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  typeButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    marginHorizontal: 4,
    alignItems: 'center',
  },
  selectedTypeButton: {
    backgroundColor: '#E8F5E9',
  },
  typeButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#666666',
  },
  selectedTypeButtonText: {
    color: '#2E7D32',
  },
  inputContainer: {
    marginBottom: 16,
  },
  label: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#666666',
    marginBottom: 8,
  },
  input: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: '#333333',
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 12,
  },
  row: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  button: {
    flex: 1,
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: '#FFEBEE',
    marginRight: 8,
  },
  saveButton: {
    backgroundColor: '#2E7D32',
    marginLeft: 8,
  },
  cancelButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: '#E53935',
  },
  saveButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: '#FFFFFF',
  },
});