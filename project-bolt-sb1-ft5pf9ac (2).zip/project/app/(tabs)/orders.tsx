import { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Platform } from 'react-native';
import { ShoppingBag, ArrowDown } from 'lucide-react-native';
import OrderItem from '@/components/OrderItem';
import { useOrders } from '@/context/OrdersContext';
import { useRouter } from 'expo-router';

export default function OrdersScreen() {
  const { orders } = useOrders();
  const [activeTab, setActiveTab] = useState<'active' | 'past'>('active');
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const router = useRouter();
  
  const activeOrders = orders.filter(order => 
    ['pending', 'processing', 'shipped'].includes(order.status)
  );
  
  const pastOrders = orders.filter(order => 
    ['delivered', 'cancelled'].includes(order.status)
  );

  const displayOrders = activeTab === 'active' ? activeOrders : pastOrders;
  const filteredOrders = statusFilter 
    ? displayOrders.filter(order => order.status === statusFilter)
    : displayOrders;

  const handleOrderPress = (orderId: string) => {
    router.push(`/orders/${orderId}`);
  };

  const handleTrackOrder = (orderId: string) => {
    router.push(`/orders/${orderId}/track`);
  };

  const handleReviewOrder = (orderId: string) => {
    router.push(`/orders/${orderId}/review`);
  };

  const handleReorder = (orderId: string) => {
    router.push(`/orders/${orderId}/reorder`);
  };

  const renderOrderStatusFilter = () => {
    const statusOptions = activeTab === 'active' 
      ? ['All', 'Pending', 'Processing', 'Shipped'] 
      : ['All', 'Delivered', 'Cancelled'];
    
    return (
      <View style={styles.filterContainer}>
        <Text style={styles.filterLabel}>Filter by status:</Text>
        <View style={styles.filterOptions}>
          {statusOptions.map(status => (
            <TouchableOpacity
              key={status}
              style={[
                styles.filterOption,
                statusFilter === status.toLowerCase() || (status === 'All' && statusFilter === null)
                  ? styles.activeFilterOption
                  : null
              ]}
              onPress={() => setStatusFilter(status === 'All' ? null : status.toLowerCase())}
            >
              <Text 
                style={[
                  styles.filterOptionText,
                  statusFilter === status.toLowerCase() || (status === 'All' && statusFilter === null)
                    ? styles.activeFilterOptionText
                    : null
                ]}
              >
                {status}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>My Orders</Text>
        <TouchableOpacity style={styles.sortButton}>
          <Text style={styles.sortButtonText}>Sort by</Text>
          <ArrowDown size={16} color="#333" />
        </TouchableOpacity>
      </View>

      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'active' && styles.activeTab]}
          onPress={() => setActiveTab('active')}
        >
          <Text style={[styles.tabText, activeTab === 'active' && styles.activeTabText]}>
            Active Orders
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'past' && styles.activeTab]}
          onPress={() => setActiveTab('past')}
        >
          <Text style={[styles.tabText, activeTab === 'past' && styles.activeTabText]}>
            Past Orders
          </Text>
        </TouchableOpacity>
      </View>

      {renderOrderStatusFilter()}

      {filteredOrders.length === 0 ? (
        <View style={styles.emptyContainer}>
          <ShoppingBag size={64} color="#CCCCCC" />
          <Text style={styles.emptyTitle}>No orders found</Text>
          <Text style={styles.emptySubtitle}>
            {activeTab === 'active' 
              ? "You don't have any active orders right now." 
              : "You don't have any past orders."}
          </Text>
          <TouchableOpacity 
            style={styles.shopButton}
            onPress={() => router.push('/(tabs)')}
          >
            <Text style={styles.shopButtonText}>Browse Products</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={filteredOrders}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <OrderItem 
              order={item}
              onPress={() => handleOrderPress(item.id)}
              onTrack={() => handleTrackOrder(item.id)}
              onReview={() => handleReviewOrder(item.id)}
              onReorder={() => handleReorder(item.id)}
            />
          )}
          contentContainerStyle={styles.ordersList}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  headerTitle: {
    fontFamily: 'Poppins-Bold',
    fontSize: 20,
    color: '#333333',
  },
  sortButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  sortButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#333333',
    marginRight: 4,
  },
  tabs: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  tab: {
    flex: 1,
    paddingVertical: 16,
    alignItems: 'center',
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: '#2E7D32',
  },
  tabText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#757575',
  },
  activeTabText: {
    color: '#2E7D32',
  },
  filterContainer: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  filterLabel: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#333333',
    marginBottom: 8,
  },
  filterOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  filterOption: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: '#F5F5F5',
    marginRight: 8,
    marginBottom: 8,
  },
  activeFilterOption: {
    backgroundColor: '#E8F5E9',
  },
  filterOptionText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: '#757575',
  },
  activeFilterOptionText: {
    color: '#2E7D32',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  emptyTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: '#333333',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#757575',
    textAlign: 'center',
    marginBottom: 24,
  },
  shopButton: {
    backgroundColor: '#2E7D32',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  shopButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#FFFFFF',
  },
  ordersList: {
    padding: 16,
  },
});