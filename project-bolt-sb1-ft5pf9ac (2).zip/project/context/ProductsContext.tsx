import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface Product {
  id: string;
  name: string;
  price: number;
  unit: string;
  image: string;
  farmerName: string;
  farmerLocation: string;
  category: string;
  description: string;
  stock: number;
  rating: number;
  organic: boolean;
}

interface ProductsContextType {
  products: Product[];
  loading: boolean;
  error: string | null;
  fetchProducts: () => void;
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
}

const ProductsContext = createContext<ProductsContextType>({
  products: [],
  loading: false,
  error: null,
  fetchProducts: () => {},
  addProduct: () => {},
  updateProduct: () => {},
  deleteProduct: () => {},
});

export function useProducts() {
  return useContext(ProductsContext);
}

interface ProductsProviderProps {
  children: ReactNode;
}

export function ProductsProvider({ children }: ProductsProviderProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProducts = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const mockProducts: Product[] = [
        {
          id: '1',
          name: 'Organic Tomatoes',
          price: 2.99,
          unit: 'kg',
          image: 'https://images.pexels.com/photos/1327838/pexels-photo-1327838.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          farmerName: 'Green Valley Farm',
          farmerLocation: 'Vermont',
          category: 'vegetables',
          description: 'Fresh organic tomatoes grown without pesticides.',
          stock: 50,
          rating: 4.8,
          organic: true,
        },
        {
          id: '2',
          name: 'Fresh Apples',
          price: 3.49,
          unit: 'kg',
          image: 'https://images.pexels.com/photos/1510392/pexels-photo-1510392.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          farmerName: 'Sunrise Orchards',
          farmerLocation: 'Washington',
          category: 'fruits',
          description: 'Crisp and juicy apples picked at peak ripeness.',
          stock: 75,
          rating: 4.5,
          organic: false,
        },
        {
          id: '3',
          name: 'Raw Honey',
          price: 8.99,
          unit: 'jar',
          image: 'https://images.pexels.com/photos/1662371/pexels-photo-1662371.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          farmerName: 'Bee Haven',
          farmerLocation: 'Oregon',
          category: 'dairy',
          description: 'Pure, unfiltered honey from wildflower meadows.',
          stock: 30,
          rating: 4.9,
          organic: true,
        },
        {
          id: '4',
          name: 'Free-Range Eggs',
          price: 5.99,
          unit: 'dozen',
          image: 'https://images.pexels.com/photos/162712/egg-white-food-protein-162712.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          farmerName: 'Happy Hens Farm',
          farmerLocation: 'California',
          category: 'dairy',
          description: 'Eggs from free-roaming, pasture-raised chickens.',
          stock: 40,
          rating: 4.7,
          organic: true,
        },
        {
          id: '5',
          name: 'Organic Brown Rice',
          price: 4.49,
          unit: 'kg',
          image: 'https://images.pexels.com/photos/7438985/pexels-photo-7438985.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          farmerName: 'Grain Valley',
          farmerLocation: 'Arkansas',
          category: 'grains',
          description: 'Certified organic whole grain brown rice.',
          stock: 100,
          rating: 4.6,
          organic: true,
        },
        {
          id: '6',
          name: 'Fresh Basil',
          price: 2.49,
          unit: 'bunch',
          image: 'https://images.pexels.com/photos/36435/alice-looking-glass-bubble-surreal.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          farmerName: 'Herb Garden',
          farmerLocation: 'Florida',
          category: 'herbs',
          description: 'Aromatic fresh basil, perfect for cooking and garnishing.',
          stock: 25,
          rating: 4.4,
          organic: false,
        },
      ];
      
      setProducts(mockProducts);
    } catch (err) {
      setError('Failed to fetch products');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const addProduct = (product: Omit<Product, 'id'>) => {
    const newProduct = {
      ...product,
      id: Math.random().toString(36).substring(7),
    };
    
    setProducts(prev => [...prev, newProduct]);
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts(prev =>
      prev.map(product =>
        product.id === id ? { ...product, ...updates } : product
      )
    );
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(product => product.id !== id));
  };

  // Initial fetch
  useEffect(() => {
    fetchProducts();
  }, []);

  const value = {
    products,
    loading,
    error,
    fetchProducts,
    addProduct,
    updateProduct,
    deleteProduct,
  };

  return <ProductsContext.Provider value={value}>{children}</ProductsContext.Provider>;
}