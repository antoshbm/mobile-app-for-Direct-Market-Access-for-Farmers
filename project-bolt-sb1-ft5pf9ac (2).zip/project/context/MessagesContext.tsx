import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  read: boolean;
}

interface Conversation {
  id: string;
  name: string;
  lastMessage: string;
  time: string;
  image: string;
  unreadCount: number;
  userType: 'farmer' | 'consumer' | 'retailer';
  messages: Message[];
}

interface MessagesContextType {
  conversations: Conversation[];
  loading: boolean;
  error: string | null;
  fetchConversations: () => void;
  getMessages: (conversationId: string) => Message[];
  sendMessage: (conversationId: string, text: string) => void;
  markAsRead: (conversationId: string) => void;
}

const MessagesContext = createContext<MessagesContextType>({
  conversations: [],
  loading: false,
  error: null,
  fetchConversations: () => {},
  getMessages: () => [],
  sendMessage: () => {},
  markAsRead: () => {},
});

export function useMessages() {
  return useContext(MessagesContext);
}

interface MessagesProviderProps {
  children: ReactNode;
}

export function MessagesProvider({ children }: MessagesProviderProps) {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchConversations = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const mockConversations: Conversation[] = [
        {
          id: '1',
          name: 'Green Valley Farm',
          lastMessage: 'Are those tomatoes still available?',
          time: '10:45 AM',
          image: 'https://images.pexels.com/photos/2382665/pexels-photo-2382665.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          unreadCount: 2,
          userType: 'farmer',
          messages: [
            {
              id: '101',
              senderId: 'user',
              text: 'Hello, do you have any fresh tomatoes available?',
              timestamp: '2023-11-15T10:30:00Z',
              read: true,
            },
            {
              id: '102',
              senderId: 'other',
              text: 'Yes, we have organic tomatoes freshly harvested this morning!',
              timestamp: '2023-11-15T10:35:00Z',
              read: true,
            },
            {
              id: '103',
              senderId: 'user',
              text: 'Great! How much per kg?',
              timestamp: '2023-11-15T10:37:00Z',
              read: true,
            },
            {
              id: '104',
              senderId: 'other',
              text: 'They are $2.99 per kg, or $7.99 for 3kg.',
              timestamp: '2023-11-15T10:40:00Z',
              read: true,
            },
            {
              id: '105',
              senderId: 'user',
              text: 'Are those tomatoes still available?',
              timestamp: '2023-11-15T10:45:00Z',
              read: false,
            },
          ],
        },
        {
          id: '2',
          name: 'Sunrise Organics',
          lastMessage: 'Your order has been shipped!',
          time: 'Yesterday',
          image: 'https://images.pexels.com/photos/2306981/pexels-photo-2306981.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          unreadCount: 1,
          userType: 'farmer',
          messages: [
            {
              id: '201',
              senderId: 'user',
              text: 'Hi, I would like to order some apples.',
              timestamp: '2023-11-14T14:20:00Z',
              read: true,
            },
            {
              id: '202',
              senderId: 'other',
              text: 'We have Red Delicious and Granny Smith. Which would you prefer?',
              timestamp: '2023-11-14T14:25:00Z',
              read: true,
            },
            {
              id: '203',
              senderId: 'user',
              text: 'I would like 2kg of Granny Smith please.',
              timestamp: '2023-11-14T14:30:00Z',
              read: true,
            },
            {
              id: '204',
              senderId: 'other',
              text: 'Your order has been shipped!',
              timestamp: '2023-11-14T16:45:00Z',
              read: false,
            },
          ],
        },
        {
          id: '3',
          name: 'Alice Johnson',
          lastMessage: 'I would like to purchase 5kg of organic rice.',
          time: 'Monday',
          image: 'https://images.pexels.com/photos/1542252/pexels-photo-1542252.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          unreadCount: 0,
          userType: 'consumer',
          messages: [
            {
              id: '301',
              senderId: 'other',
              text: 'Hello, I saw your listing for organic rice.',
              timestamp: '2023-11-13T09:10:00Z',
              read: true,
            },
            {
              id: '302',
              senderId: 'user',
              text: 'Yes, we have premium quality organic brown rice available.',
              timestamp: '2023-11-13T09:15:00Z',
              read: true,
            },
            {
              id: '303',
              senderId: 'other',
              text: 'I would like to purchase 5kg of organic rice.',
              timestamp: '2023-11-13T09:20:00Z',
              read: true,
            },
          ],
        },
        {
          id: '4',
          name: 'Fresh Market',
          lastMessage: 'We would like to place a bulk order for your farm.',
          time: 'Last week',
          image: 'https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
          unreadCount: 0,
          userType: 'retailer',
          messages: [
            {
              id: '401',
              senderId: 'other',
              text: 'Hello, we are a local grocery store interested in your produce.',
              timestamp: '2023-11-08T11:00:00Z',
              read: true,
            },
            {
              id: '402',
              senderId: 'user',
              text: 'Hi there! We would be happy to supply your store. What products are you interested in?',
              timestamp: '2023-11-08T11:10:00Z',
              read: true,
            },
            {
              id: '403',
              senderId: 'other',
              text: 'We would like to place a bulk order for your farm.',
              timestamp: '2023-11-08T11:15:00Z',
              read: true,
            },
          ],
        },
      ];
      
      setConversations(mockConversations);
    } catch (err) {
      setError('Failed to fetch conversations');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getMessages = (conversationId: string): Message[] => {
    const conversation = conversations.find(c => c.id === conversationId);
    return conversation ? conversation.messages : [];
  };

  const sendMessage = (conversationId: string, text: string) => {
    const now = new Date();
    const newMessage: Message = {
      id: Math.random().toString(36).substring(7),
      senderId: 'user',
      text,
      timestamp: now.toISOString(),
      read: true,
    };
    
    setConversations(prev =>
      prev.map(conversation => {
        if (conversation.id === conversationId) {
          return {
            ...conversation,
            lastMessage: text,
            time: formatTime(now),
            messages: [...conversation.messages, newMessage],
          };
        }
        return conversation;
      })
    );
  };

  const markAsRead = (conversationId: string) => {
    setConversations(prev =>
      prev.map(conversation => {
        if (conversation.id === conversationId) {
          return {
            ...conversation,
            unreadCount: 0,
            messages: conversation.messages.map(message => ({ ...message, read: true })),
          };
        }
        return conversation;
      })
    );
  };

  const formatTime = (date: Date): string => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const oneDay = 24 * 60 * 60 * 1000;
    
    if (diff < oneDay) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diff < 2 * oneDay) {
      return 'Yesterday';
    } else if (diff < 7 * oneDay) {
      return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][date.getDay()];
    } else {
      return date.toLocaleDateString();
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchConversations();
  }, []);

  const value = {
    conversations,
    loading,
    error,
    fetchConversations,
    getMessages,
    sendMessage,
    markAsRead,
  };

  return <MessagesContext.Provider value={value}>{children}</MessagesContext.Provider>;
}