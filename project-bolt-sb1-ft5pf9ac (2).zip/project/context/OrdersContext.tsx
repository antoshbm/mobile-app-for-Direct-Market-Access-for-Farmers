import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface OrderProduct {
  id: string;
  name: string;
  quantity: number;
  price: number;
  image: string;
}

interface Order {
  id: string;
  date: string;
  status: string;
  totalAmount: number;
  products: OrderProduct[];
  farmerName: string;
  farmerImage: string;
}

interface OrdersContextType {
  orders: Order[];
  loading: boolean;
  error: string | null;
  fetchOrders: () => void;
  placeOrder: (products: OrderProduct[], farmerName: string, farmerImage: string) => void;
  cancelOrder: (id: string) => void;
}

const OrdersContext = createContext<OrdersContextType>({
  orders: [],
  loading: false,
  error: null,
  fetchOrders: () => {},
  placeOrder: () => {},
  cancelOrder: () => {},
});

export function useOrders() {
  return useContext(OrdersContext);
}

interface OrdersProviderProps {
  children: ReactNode;
}

export function OrdersProvider({ children }: OrdersProviderProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchOrders = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const mockOrders: Order[] = [
        {
          id: '1',
          date: '2023-10-15',
          status: 'delivered',
          totalAmount: 24.98,
          products: [
            {
              id: '1',
              name: 'Organic Tomatoes',
              quantity: 2,
              price: 2.99,
              image: 'https://images.pexels.com/photos/1327838/pexels-photo-1327838.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            },
            {
              id: '3',
              name: 'Raw Honey',
              quantity: 1,
              price: 8.99,
              image: 'https://images.pexels.com/photos/1662371/pexels-photo-1662371.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            },
            {
              id: '6',
              name: 'Fresh Basil',
              quantity: 4,
              price: 2.49,
              image: 'https://images.pexels.com/photos/36435/alice-looking-glass-bubble-surreal.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            }
          ],
          farmerName: 'Green Valley Farm',
          farmerImage: 'https://images.pexels.com/photos/2382665/pexels-photo-2382665.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        },
        {
          id: '2',
          date: '2023-11-02',
          status: 'shipped',
          totalAmount: 13.47,
          products: [
            {
              id: '2',
              name: 'Fresh Apples',
              quantity: 3,
              price: 3.49,
              image: 'https://images.pexels.com/photos/1510392/pexels-photo-1510392.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            },
            {
              id: '6',
              name: 'Fresh Basil',
              quantity: 1,
              price: 2.49,
              image: 'https://images.pexels.com/photos/36435/alice-looking-glass-bubble-surreal.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            }
          ],
          farmerName: 'Sunrise Orchards',
          farmerImage: 'https://images.pexels.com/photos/2306981/pexels-photo-2306981.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        },
        {
          id: '3',
          date: '2023-11-10',
          status: 'processing',
          totalAmount: 19.47,
          products: [
            {
              id: '4',
              name: 'Free-Range Eggs',
              quantity: 2,
              price: 5.99,
              image: 'https://images.pexels.com/photos/162712/egg-white-food-protein-162712.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            },
            {
              id: '5',
              name: 'Organic Brown Rice',
              quantity: 1,
              price: 4.49,
              image: 'https://images.pexels.com/photos/7438985/pexels-photo-7438985.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            }
          ],
          farmerName: 'Happy Hens Farm',
          farmerImage: 'https://images.pexels.com/photos/1112080/pexels-photo-1112080.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        },
        {
          id: '4',
          date: '2023-11-15',
          status: 'pending',
          totalAmount: 8.99,
          products: [
            {
              id: '3',
              name: 'Raw Honey',
              quantity: 1,
              price: 8.99,
              image: 'https://images.pexels.com/photos/1662371/pexels-photo-1662371.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            }
          ],
          farmerName: 'Bee Haven',
          farmerImage: 'https://images.pexels.com/photos/6147369/pexels-photo-6147369.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        },
        {
          id: '5',
          date: '2023-09-22',
          status: 'cancelled',
          totalAmount: 26.94,
          products: [
            {
              id: '2',
              name: 'Fresh Apples',
              quantity: 5,
              price: 3.49,
              image: 'https://images.pexels.com/photos/1510392/pexels-photo-1510392.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            },
            {
              id: '5',
              name: 'Organic Brown Rice',
              quantity: 2,
              price: 4.49,
              image: 'https://images.pexels.com/photos/7438985/pexels-photo-7438985.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
            }
          ],
          farmerName: 'Grain Valley',
          farmerImage: 'https://images.pexels.com/photos/1438832/pexels-photo-1438832.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        }
      ];
      
      setOrders(mockOrders);
    } catch (err) {
      setError('Failed to fetch orders');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const placeOrder = (products: OrderProduct[], farmerName: string, farmerImage: string) => {
    const totalAmount = products.reduce((sum, product) => sum + (product.price * product.quantity), 0);
    
    const newOrder: Order = {
      id: Math.random().toString(36).substring(7),
      date: new Date().toISOString().split('T')[0],
      status: 'pending',
      totalAmount,
      products,
      farmerName,
      farmerImage,
    };
    
    setOrders(prev => [newOrder, ...prev]);
  };

  const cancelOrder = (id: string) => {
    setOrders(prev =>
      prev.map(order =>
        order.id === id ? { ...order, status: 'cancelled' } : order
      )
    );
  };

  // Initial fetch
  useEffect(() => {
    fetchOrders();
  }, []);

  const value = {
    orders,
    loading,
    error,
    fetchOrders,
    placeOrder,
    cancelOrder,
  };

  return <OrdersContext.Provider value={value}>{children}</OrdersContext.Provider>;
}